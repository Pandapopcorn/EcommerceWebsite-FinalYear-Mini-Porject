<?php
session_start();
require_once '../../config/database.php';

// Optionally check admin auth
// if (!isset($_SESSION['admin_logged_in'])) { http_response_code(403); exit; }

$database = new Database();
$db = $database->getConnection();

// Total products
$stmt = $db->query('SELECT COUNT(*) AS c FROM products');
$total_products = (int)$stmt->fetch(PDO::FETCH_ASSOC)['c'];

// Total orders
$stmt = $db->query('SELECT COUNT(*) AS c FROM orders');
$total_orders = (int)$stmt->fetch(PDO::FETCH_ASSOC)['c'];

// Total customers
$stmt = $db->query('SELECT COUNT(*) AS c FROM users');
$total_customers = (int)$stmt->fetch(PDO::FETCH_ASSOC)['c'];

// Total revenue
$stmt = $db->query('SELECT COALESCE(SUM(total_amount), 0) AS s FROM orders');
$total_revenue = number_format((float)$stmt->fetch(PDO::FETCH_ASSOC)['s'], 2);

echo json_encode([
	'total_products' => $total_products,
	'total_orders' => $total_orders,
	'total_customers' => $total_customers,
	'total_revenue' => $total_revenue,
]);
?> 