<?php
session_start();

// Simple admin authentication (enhance this for production)
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}

include '../includes/header.php';
?>

<div class="container-fluid my-4">
    <div class="row">
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">
                    <h5>Admin Panel</h5>
                </div>
                <div class="list-group list-group-flush">
                    <a href="#" class="list-group-item list-group-item-action active" onclick="showSection('dashboard')">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="#" class="list-group-item list-group-item-action" onclick="showSection('products')">
                        <i class="fas fa-box"></i> Products
                    </a>
                    <a href="#" class="list-group-item list-group-item-action" onclick="showSection('orders')">
                        <i class="fas fa-shopping-bag"></i> Orders
                    </a>
                    <a href="#" class="list-group-item list-group-item-action" onclick="showSection('customers')">
                        <i class="fas fa-users"></i> Customers
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-10">
            <!-- Dashboard Section -->
            <div id="dashboard" class="admin-section">
                <h3>Dashboard</h3>
                <div class="row">
                    <div class="col-md-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <h5>Total Products</h5>
                                <h2 id="total-products">0</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h5>Total Orders</h5>
                                <h2 id="total-orders">0</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <h5>Total Customers</h5>
                                <h2 id="total-customers">0</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body">
                                <h5>Total Revenue</h5>
                                <h2 id="total-revenue">$0</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Products Section -->
            <div id="products" class="admin-section" style="display: none;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Products</h3>
                    <button class="btn btn-primary" onclick="showAddProductModal()">Add Product</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="products-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Category</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="products-tbody">
                            <!-- Products will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Orders Section -->
            <div id="orders" class="admin-section" style="display: none;">
                <h3>Orders</h3>
                <div class="table-responsive">
                    <table class="table table-striped" id="orders-table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="orders-tbody">
                            <!-- Orders will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Customers Section -->
            <div id="customers" class="admin-section" style="display: none;">
                <h3>Customers</h3>
                <div class="table-responsive">
                    <table class="table table-striped" id="customers-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="customers-tbody">
                            <!-- Customers will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    loadDashboardStats();
});

function showSection(sectionId) {
    $('.admin-section').hide();
    $('#' + sectionId).show();
    
    $('.list-group-item').removeClass('active');
    $('[onclick="showSection(\'' + sectionId + '\')"]').addClass('active');
    
    // Load data based on section
    switch(sectionId) {
        case 'products':
            loadProducts();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'customers':
            loadCustomers();
            break;
    }
}

function loadDashboardStats() {
    $.ajax({
        url: 'api/dashboard_stats.php',
        method: 'GET',
        success: function(response) {
            const stats = JSON.parse(response);
            $('#total-products').text(stats.total_products);
            $('#total-orders').text(stats.total_orders);
            $('#total-customers').text(stats.total_customers);
            $('#total-revenue').text('$' + stats.total_revenue);
        }
    });
}

function loadProducts() {
    // Implementation for loading products in admin
}

function loadOrders() {
    // Implementation for loading orders in admin
}

function loadCustomers() {
    // Implementation for loading customers in admin
}
</script>

<?php include '../includes/footer.php'; ?> 