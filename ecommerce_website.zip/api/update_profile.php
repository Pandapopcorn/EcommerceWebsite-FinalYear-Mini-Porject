<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
	echo json_encode(['success' => false, 'message' => 'Please login first']);
	exit;
}

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$address = $_POST['address'] ?? '';

// Validation
if (empty($name) || empty($email)) {
	echo json_encode(['success' => false, 'message' => 'Name and email are required']);
	exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	echo json_encode(['success' => false, 'message' => 'Invalid email format']);
	exit;
}

$database = new Database();
$db = $database->getConnection();

// Check if email exists for another user
$query = "SELECT id FROM users WHERE email = ? AND id != ?";
$stmt = $db->prepare($query);
$stmt->execute([$email, $_SESSION['user_id']]);

if ($stmt->fetch()) {
	echo json_encode(['success' => false, 'message' => 'Email already exists']);
	exit;
}

// Update user profile
$query = "UPDATE users SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?";
$stmt = $db->prepare($query);

if ($stmt->execute([$name, $email, $phone, $address, $_SESSION['user_id']])) {
	$_SESSION['user_name'] = $name;
	echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
} else {
	echo json_encode(['success' => false, 'message' => 'Update failed']);
}
?> 