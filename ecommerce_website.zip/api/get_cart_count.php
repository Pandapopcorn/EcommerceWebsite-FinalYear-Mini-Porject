<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => true, 'count' => 0]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT SUM(quantity) as total FROM cart WHERE user_id = ?";
$stmt = $db->prepare($query);
$stmt->execute([$_SESSION['user_id']]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$count = $result['total'] ?? 0;
echo json_encode(['success' => true, 'count' => (int)$count]);
?> 