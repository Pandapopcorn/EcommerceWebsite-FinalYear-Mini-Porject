<?php
require_once '../config/database.php';

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$password = $_POST['password'] ?? '';
$address = $_POST['address'] ?? '';

// Validation
if (empty($name) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

// Check if email already exists
$query = "SELECT id FROM users WHERE email = ?";
$stmt = $db->prepare($query);
$stmt->execute([$email]);

if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Email already exists']);
    exit;
}

// Hash password and insert user
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$query = "INSERT INTO users (name, email, phone, password, address) VALUES (?, ?, ?, ?, ?)";
$stmt = $db->prepare($query);

if ($stmt->execute([$name, $email, $phone, $hashed_password, $address])) {
    echo json_encode(['success' => true, 'message' => 'User registered successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Registration failed']);
}
?> 