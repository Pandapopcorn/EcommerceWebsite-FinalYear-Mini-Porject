<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
	echo json_encode(['success' => false, 'message' => 'Please login first']);
	exit;
}

$current_password = $_POST['current_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';

// Validation
if (empty($current_password) || empty($new_password)) {
	echo json_encode(['success' => false, 'message' => 'Please fill all fields']);
	exit;
}

if (strlen($new_password) < 6) {
	echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
	exit;
}

$database = new Database();
$db = $database->getConnection();

// Get current user
$query = "SELECT password FROM users WHERE id = ?";
$stmt = $db->prepare($query);
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($current_password, $user['password'])) {
	echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
	exit;
}

// Update password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
$query = "UPDATE users SET password = ? WHERE id = ?";
$stmt = $db->prepare($query);

if ($stmt->execute([$hashed_password, $_SESSION['user_id']])) {
	echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
} else {
	echo json_encode(['success' => false, 'message' => 'Password change failed']);
}
?> 