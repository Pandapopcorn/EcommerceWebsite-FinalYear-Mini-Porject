<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$limit = $_GET['limit'] ?? null;
$category = $_GET['category'] ?? '';
$max_price = $_GET['max_price'] ?? null;
$search = $_GET['search'] ?? '';

$query = "SELECT * FROM products WHERE 1=1";
$params = [];

if (!empty($category)) {
    $query .= " AND category = ?";
    $params[] = $category;
}

if (!empty($max_price)) {
    $query .= " AND price <= ?";
    $params[] = $max_price;
}

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$query .= " ORDER BY created_at DESC";

if ($limit) {
    $query .= " LIMIT ?";
    $params[] = (int)$limit;
}

$stmt = $db->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($products);
?> 