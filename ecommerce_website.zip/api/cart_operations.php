<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'add':
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'] ?? 1;
        $user_id = $_SESSION['user_id'];
        
        // Check if item already exists in cart
        $query = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$user_id, $product_id]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            // Update quantity
            $query = "UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$quantity, $user_id, $product_id]);
        } else {
            // Add new item
            $query = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
            $stmt = $db->prepare($query);
            $stmt->execute([$user_id, $product_id, $quantity]);
        }
        
        echo json_encode(['success' => true]);
        break;
        
    case 'update':
        $cart_id = $_POST['cart_id'];
        $quantity = $_POST['quantity'];
        
        $query = "UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$quantity, $cart_id, $_SESSION['user_id']]);
        
        echo json_encode(['success' => true]);
        break;
        
    case 'remove':
        $cart_id = $_POST['cart_id'];
        
        $query = "DELETE FROM cart WHERE id = ? AND user_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$cart_id, $_SESSION['user_id']]);
        
        echo json_encode(['success' => true]);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?> 