// Global functions
function showAlert(message, type = 'info') {
    const alertDiv = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    $('.alert').remove();
    $('body').prepend(alertDiv);
    setTimeout(() => { $('.alert').fadeOut(); }, 5000);
}

function getApiBase() {
    // If path contains /admin/, go up one level for API
    return window.location.pathname.indexOf('/admin/') !== -1 ? '../' : '';
}

function addToCart(productId, quantity = 1) {
    $.ajax({
        url: getApiBase() + 'api/cart_operations.php',
        method: 'POST',
        data: { action: 'add', product_id: productId, quantity: quantity },
        success: function(response) {
            const result = JSON.parse(response);
            if (result.success) {
                showAlert('Product added to cart successfully!', 'success');
                updateCartCount();
            } else {
                showAlert(result.message, 'danger');
            }
        },
        error: function() {
            showAlert('Error adding product to cart', 'danger');
        }
    });
}

function updateCartCount() {
    $.ajax({
        url: getApiBase() + 'api/get_cart_count.php',
        method: 'GET',
        success: function(response) {
            const result = JSON.parse(response);
            if (result.success) { $('#cart-count').text(result.count); }
        }
    });
}

$(document).ready(function() {
    updateCartCount();
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\+]?[1-9][\d]{0,15}$/;
    return re.test(phone);
}

function formatPrice(price) { return '$' + parseFloat(price).toFixed(2); }

function showLoading(element) {
    $(element).html('<div class="text-center"><div class="spinner-border" role="status"></div></div>');
}

function hideLoading() { $('.spinner-border').closest('div').remove(); } 